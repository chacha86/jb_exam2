package TextBoard;




public class Main {
    public static void main(String[] args){
        TextBoard textBoard = new TextBoard();
        textBoard.run();
    }
}
