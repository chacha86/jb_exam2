package TextBoard;

import TextBoard.article.ArticleControl;
import TextBoard.system.controller.SystemController;

import java.util.Scanner;
import TextBoard.article.ArticleControl;
import TextBoard.system.controller.SystemController;

import java.util.*;
public class TextBoard {
    public void run(){
        Scanner scan = new Scanner(System.in);

        SystemController systemControl = new SystemController();
        ArticleControl articleControl = new ArticleControl();

        while (true) {
            System.out.printf("명령어: ");
            String cmd = scan.nextLine();

            if (cmd.equals("exit")) {
                systemControl.exit();
                break;
            }
            else if (cmd.equals("add")){
                articleControl.add();
            }
            else if (cmd.equals("list")){
                articleControl.list();
            }
            else if (cmd.equals("update")){
                articleControl.update();
            }
            else if (cmd.equals("delete")){
                articleControl.delete();
            }
            else if (cmd.equals("detail")){
                articleControl.detail();
            }
            else if (cmd.equals("search")){
                articleControl.search();
            }
        }
    }
}
