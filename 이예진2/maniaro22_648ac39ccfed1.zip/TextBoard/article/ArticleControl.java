package TextBoard.article;

import java.util.*;

import TextBoard.article.Article;
import TextBoard.util.Util;


public class ArticleControl {
    Scanner scan = new Scanner(System.in);
    ArrayList<Article> articles = new ArrayList<>();

    int id = 4;



    public ArticleControl(){
        testData();
    }
    public void testData(){
        Article article1 = new Article(1, "안녕하세요 반갑습니다. 자바 공부중이에요.","-", Util.currentDate(),0);
        Article article2 = new Article(2, "자바 질문좀 할게요~.","-",Util.currentDate(),0);
        Article article3 = new Article(3, "정처기 따야되나요?","-",Util.currentDate(),0);


        articles.add(article1);
        articles.add(article2);
        articles.add(article3);
    }

    public void add() {
        System.out.printf("게시물 제목을 입력해주세요 : ");
        String title = scan.nextLine();
        System.out.printf("게시물 내용을 입력해주세요 : ");
        String body = scan.nextLine();


        Article article = new Article(id,title,body,Util.currentDate(),0);
        articles.add(article);
        id++;

    }

    public void list() {
        System.out.println("==================");
        for(int i = 0; i < articles.size(); i++) {
            Article article = articles.get(i);

            System.out.println("번호: " + article.getId());
            System.out.println("제목: " + article.getTitle());
            System.out.println("==================");
        }
    }

    public void update() {
        System.out.printf("수정할 게시물 번호 : ");
        int target = 0;

        // 숫자만
        target = intOnly(target);
        // 인덱스 찾기
        Article article = findIndex(target);

        if(article != null){
            System.out.printf("제목 : ");
            String title = scan.nextLine();
            System.out.printf("내용 : ");
            String body = scan.nextLine();

            article.setTitle(title);
            article.setBody(body);


            System.out.printf("%d번 게시물이 수정되었습니다.\n", article.getId());
        }
        else {
            System.out.println("없는 게시물 번호입니다.");
        }

    }
    public void delete() {

        System.out.printf("삭제할 게시물 번호: ");
        int target = 0;

        // 숫자만
        target = intOnly(target);
        // 인덱스 찾기
        Article article = findIndex(target);

        if(article != null){
            articles.remove(article);
            System.out.printf("%d번 게시물이 삭제되었습니다.\n", article.getId());
        }
        else {
            System.out.println("없는 게시물 번호입니다.");
        }
    }

    public void detail() {
        System.out.printf("상세보기 할 게시물 번호를 입력해주세요: ");
        int target = 0;

        // 숫자만
        target = intOnly(target);
        // 인덱스 찾기
        Article article = findIndex(target);

        if(article != null){
            System.out.println("===================");
            System.out.printf("번호: %d\n", article.getId());
            System.out.printf("제목: %s\n", article.getTitle());
            System.out.printf("내용: %s\n", article.getBody());
            System.out.printf("등록날짜: %s\n", article.getDate());
            System.out.printf("조회수: %d\n", article.getCnt()+1);
            System.out.println("===================");
            article.setCnt(article.getCnt()+1);
        }
        else {
            System.out.println("없는 게시물 번호입니다.");
        }
    }

    public void search() {
        System.out.printf("검색 키워드를 입력해주세요: ");

        String keyword = "";
        keyword = scan.nextLine();

        Article article = null;

        System.out.println("===================");
        for(int i = 0; i < articles.size(); i++){
            if(articles.get(i).getTitle().contains(keyword) == true){
                article = articles.get(i);

                System.out.printf("번호: %d\n", article.getId());
                System.out.printf("제목: %s\n", article.getTitle());
                System.out.println("===================");
            }
        }
        if(article == null){
            System.out.println("검색 결과가 없습니다.");
        }
    }


    private Article findIndex(int target) {
        Article article = null;
        for(int i = 0; i < articles.size(); i++){
            if(articles.get(i).getId() == target){
                article = articles.get(i);
                break;
            }
        }return article;
    }

    private int intOnly(int target) {
        try {
            target = scan.nextInt();
            scan.nextLine();
        } catch (InputMismatchException e) {
            System.out.println("숫자를 입력해주세요.");
            scan.nextLine();
        }
        return target;
    }
}
