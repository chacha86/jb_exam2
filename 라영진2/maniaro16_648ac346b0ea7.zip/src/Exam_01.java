import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class Exam_01 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<String> titles = new ArrayList<>();
        ArrayList<String> contents = new ArrayList<>();
        ArrayList<Integer> ids = new ArrayList<>();
        ArrayList<Integer> views = new ArrayList<>();
        ArrayList<Date> dateList = new ArrayList<>();
        int num = 0;

        // 테스트 데이터
        titles.add("안녕하세요 반갑습니다. 자바 공부중이에요.");
        titles.add("자바 질문좀 할게요~");
        titles.add("정처기 따야되나요?");

        contents.add("");
        contents.add("MVC 패턴이 뭔가요?");
        contents.add("");

        ids.add(1);
        ids.add(2);
        ids.add(3);

        while (true) {
            System.out.print("명령어: ");
            String cmd = sc.nextLine();

            if (cmd.equals("exit")) {
                System.out.println("프로그램을 종료합니다.");
                break;
            } else if (cmd.equals("add")) {
                System.out.print("게시물 제목을 입력해주세요: ");
                String title = sc.nextLine();
                System.out.print("게시물 내용을 입력해주세요: ");
                String content = sc.nextLine();
                System.out.println("게시물이 등록되었습니다.");

                Date currentDate = new Date();
                dateList.add(currentDate);
                titles.add(title);
                contents.add(content);
                ids.add(++num); // 새로운 게시물마다 ID를 증가시킴
                views.add(0); // 초기 조회수를 0으로 설정

            } else if (cmd.equals("list")) {
                for (int i = 0; i < titles.size(); i++) {
                    System.out.println("=================");
                    System.out.println("번호: " + ids.get(i));
                    System.out.println("제목: " + titles.get(i));
                }
                if (titles.isEmpty()) {
                    System.out.println("게시물이 없습니다.");
                }

            } else if (cmd.equals("update")) {
                System.out.print("수정할 게시물 번호: ");
                String input = sc.nextLine();
                if (!isNumeric(input)) {
                    System.out.println("숫자를 입력해주세요.");
                    continue;
                }
                int postId = Integer.parseInt(input);
                int index = ids.indexOf(postId);
                if (index == -1) {
                    System.out.println("없는 게시물 번호입니다.");
                    continue;
                }
                System.out.print("새로운 제목: ");
                String newTitle = sc.nextLine();
                System.out.print("새로운 내용: ");
                String newContent = sc.nextLine();

                titles.set(index, newTitle);
                contents.set(index, newContent);
                System.out.println(postId + "번 게시물이 수정되었습니다.");

            } else if (cmd.equals("delete")) {
                System.out.print("삭제할 게시물 번호: ");
                String input = sc.nextLine();
                if (!isNumeric(input)) {
                    System.out.println("숫자를 입력해주세요.");
                    continue;
                }
                int postId = Integer.parseInt(input);
                int index = ids.indexOf(postId);
                if (index == -1) {
                    System.out.println("없는 게시물 번호입니다.");
                    continue;
                }
                titles.remove(index);
                contents.remove(index);
                ids.remove(index);
                views.remove(index);
                dateList.remove(index);
                System.out.println(postId + "번 게시물이 삭제되었습니다.");

            } else if (cmd.equals("search")) {
                System.out.print("검색할 키워드를 입력해주세요 : ");
                String keyword = sc.nextLine();
                boolean found = false;
                for (int i = 0; i < titles.size(); i++) {
                    if (titles.get(i).contains(keyword) || contents.get(i).contains(keyword)) {
                        System.out.println("=================");
                        System.out.println("번호: " + ids.get(i));
                        System.out.println("제목: " + titles.get(i));
                        System.out.println("내용: " + contents.get(i));
                        System.out.println("=================");
                        found = true;
                    }
                }
                if (!found) {
                    System.out.println("검색 결과가 없습니다.");
                }
            } else if (cmd.equals("detail")) {
                System.out.print("상세보기 할 게시물 번호를 입력해주세요 : ");
                String input = sc.nextLine();
                if (!isNumeric(input)) {
                    System.out.println("숫자를 입력해주세요.");
                    continue;
                }
                int postId = Integer.parseInt(input);
                int index = ids.indexOf(postId);
                if (index == -1) {
                    System.out.println("존재하지 않는 게시물 번호입니다.");
                    continue;
                }
                System.out.println("=================");
                System.out.println("번호: " + ids.get(index));
                System.out.println("제목: " + titles.get(index));
                System.out.println("내용: " + contents.get(index));
                System.out.println("작성일: " + dateList.get(index));
                System.out.println("조회수: " + views.get(index));

                // 조회수 증가
                views.set(index, views.get(index) + 1);
                System.out.println("조회수가 1 증가되었습니다.");

            } else {
                System.out.println("잘못된 명령어입니다. 다시 입력해주세요.");
            }
        }

        sc.close();
    }

    // 문자열이 숫자인지 확인하는 메서드
    private static boolean isNumeric(String str) {
        try {
            Integer.parseInt(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
