package assessment_2.systemcontroller;

public class SystemController {
    public void exitPost(){
        System.out.println("프로그램을 종료합니다.");
    }
}
