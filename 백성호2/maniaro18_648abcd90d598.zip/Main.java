package 시험2;

import 시험2.Util.Util;

public class Main {
    public static void main(String[] args) {

        App app=new App();
        app.Run();
    }
}
